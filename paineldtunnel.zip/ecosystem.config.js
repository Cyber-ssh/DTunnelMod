module.exports = {
  apps: [
    {
      name: 'DTunnel',
      script: './build/index.js',
    },
  ],
};
