module.exports = {
  apps: [
    {
      name: 'GESTOR-DTunnel',
      script: './build/index.js',
    },
  ],
};
